unzip yt.zip
unzip root.zip
tar -xvf root.tar.xz
./dist/proot -S . /bin/bash